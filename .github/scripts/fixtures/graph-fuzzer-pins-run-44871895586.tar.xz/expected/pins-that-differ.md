## (a) Pins that differ

```
base corpusAcceptedFeatureCounts.constantCycleCloser pinned=39 actual=364
```

